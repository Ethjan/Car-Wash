# CarWash
Car wash application in LabVIEW
